<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="template2.css">
</head>
<body><br><br>
<center><div class="selectbtn">
        Select any Template
    </div></center><br><br>
<div class="card-container">
  <div class="card">
  <a href="http://localhost/Resume/"><img  src="temp1.png" ></a>
    <!-- <div class="card-info">
      <h2>Card Title</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      <button>Read More</button>
    </div> -->
  </div>
  <div class="card">
    <a href="http://localhost/Resume1/"><img  src="temp2.png" ></a> 
    <!-- <div class="card-info">
      <h2>Card Title</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      <button>Read More</button>
    </div> -->
  </div>
  <div class="card">
  <a href="http://localhost/Resume2/"><img  src="temp3.png" ></a>
    <!-- <div class="card-info">
      <h2>Card Title</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      <button>Read More</button>
    </div> -->
  </div>
  <div class="card">
  <a href="http://localhost/Resume3/"><img  src="template3.png" ></a>
    <!-- <div class="card-info">
      <h2>Card Title</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      <button>Read More</button>
    </div> -->
  </div>
</div>

</body>
</html>